import adsk.core, adsk.fusion, traceback
import os 

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface
        design = app.activeProduct
        
        if not design:
            ui.messageBox('Nenhum design ativo aberto.')
            return
            
        rootComp = design.rootComponent



        #######################################################################################
        ############# RENOMEAR PARA O NOME DO ESBOÇO QUE ESTIVER ALI ##########################
        #######################################################################################


        nome_esboco_base = 'Esboço1'





        esboco_original = rootComp.sketches.itemByName(nome_esboco_base)
        
        if not esboco_original:
            ui.messageBox(f'Esboço "{nome_esboco_base}" não encontrado.')
            return

        # ==========================================
        # SELEÇÃO DA PASTA DE DESTINO
        # ==========================================
        folderDlg = ui.createFolderDialog()
        folderDlg.title = 'Escolha a pasta para salvar os arquivos DXF' 
        
        dlgResult = folderDlg.showDialog()
        if dlgResult == adsk.core.DialogResults.DialogOK:
            pasta_destino = folderDlg.folder
        else:
            return # Cancela a execução se fechar a janela
            
        # ==========================================
        # EXPORTAÇÃO DO ESBOÇO BASE ORIGINAL
        # ==========================================
        caminho_base = os.path.join(pasta_destino, f"{nome_esboco_base}.dxf")
        esboco_original.saveAsDXF(caminho_base)
        
        # Função algébrica para escalar vetores de posição em relação à origem (0,0)
        def escalar_ponto(pt, esc):
            return adsk.core.Point3D.create(pt.x * esc, pt.y * esc, 0)
            

        #######################################################################################
        ############# QUANTIDADE DE CAMADAS NECESSÁRIAS MENOS UMA #############################
        #######################################################################################

        qtd = 2
        
        # 1. Normalização matemática da série (garantir que a última é 0.5)
        soma_total_serie = 0.0
        for n in range(2, qtd + 2):
            soma_total_serie += 1.0 / ((2.0 * n) - 2.0)
            
        escala_atual = 1.0
        
        # 2. Gerar as iterações, reconstruir as matrizes e exportar
        for n in range(2, qtd + 2):
            termo = 1.0 / ((2.0 * n) - 2.0)
            passo_reducao = 0.5 * (termo / soma_total_serie)
            escala_atual -= passo_reducao
            
            nome_identificador = f"Perfil_{n-1}_Escala_{escala_atual:.3f}"
            
            novo_esboco = rootComp.sketches.add(esboco_original.referencePlane)
            novo_esboco.name = nome_identificador
            
            # -- RECONSTRUÇÃO DE LINHAS --
            for linha in esboco_original.sketchCurves.sketchLines:
                p1 = escalar_ponto(linha.startSketchPoint.geometry, escala_atual)
                p2 = escalar_ponto(linha.endSketchPoint.geometry, escala_atual)
                nova_linha = novo_esboco.sketchCurves.sketchLines.addByTwoPoints(p1, p2)
                nova_linha.isConstruction = linha.isConstruction
                
            # -- RECONSTRUÇÃO DE SPLINES --
            for spline in esboco_original.sketchCurves.sketchFittedSplines:
                pontos_escala = adsk.core.ObjectCollection.create()
                for pt in spline.fitPoints:
                    pontos_escala.add(escalar_ponto(pt.geometry, escala_atual))
                nova_spline = novo_esboco.sketchCurves.sketchFittedSplines.add(pontos_escala)
                nova_spline.isConstruction = spline.isConstruction
                
            # -- RECONSTRUÇÃO DE CÍRCULOS --
            for circulo in esboco_original.sketchCurves.sketchCircles:
                centro = escalar_ponto(circulo.centerSketchPoint.geometry, escala_atual)
                raio = circulo.radius * escala_atual
                novo_circ = novo_esboco.sketchCurves.sketchCircles.addByCenterRadius(centro, raio)
                novo_circ.isConstruction = circulo.isConstruction
                
            # -- RECONSTRUÇÃO DE ARCOS --
            for arco in esboco_original.sketchCurves.sketchArcs:
                p1 = escalar_ponto(arco.startSketchPoint.geometry, escala_atual)
                p2 = escalar_ponto(arco.endSketchPoint.geometry, escala_atual)
                
                evaluator = arco.geometry.evaluator
                _, startParam, endParam = evaluator.getParameterExtents()
                midParam = (startParam + endParam) / 2.0
                _, p_meio_orig = evaluator.getPointAtParameter(midParam)
                
                p_meio = escalar_ponto(p_meio_orig, escala_atual)
                novo_arco = novo_esboco.sketchCurves.sketchArcs.addByThreePoints(p1, p_meio, p2)
                novo_arco.isConstruction = arco.isConstruction

            # ==========================================
            # EXPORTAÇÃO DAS CÓPIAS GERADAS
            # ==========================================
            nome_arquivo = f"{nome_identificador}.dxf"
            caminho_completo = os.path.join(pasta_destino, nome_arquivo)
            novo_esboco.saveAsDXF(caminho_completo)

        ui.messageBox(f'Sucesso! O Esboço Base e mais {qtd} cópias foram exportados para:\n{pasta_destino}')
        
    except:
        if ui:
            ui.messageBox('Falha no script:\n{}'.format(traceback.format_exc()))