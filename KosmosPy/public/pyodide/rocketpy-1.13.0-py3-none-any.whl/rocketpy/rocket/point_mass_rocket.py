"""Point mass rocket class for simplified 3-DOF trajectory simulations."""

from rocketpy.rocket.rocket import Rocket


class PointMassRocket(Rocket):
    """A simplified rocket class for trajectory simulations where the rocket
    is modeled as a point mass.

    This class omits rotational dynamics and complex inertial properties,
    focusing solely on translational (3-DOF) motion based on mass and
    aerodynamics. Appropriate for educational use, quick analyses, or when
    rotational effects are negligible.

    Parameters
    ----------
    radius : float
        Rocket's largest radius in meters.
    mass : float
        Rocket's mass without motor in kg.
    center_of_mass_without_motor : float
        Position, in meters, of the rocket's center of mass without motor
        relative to the rocket's coordinate system.
    power_off_drag : int, float, callable, array, string, Function
        Drag coefficient input when the motor is off. Accepts the same formats
        as :class:`rocketpy.Rocket`, including 1D (Mach-only) and 7D
        (alpha, beta, mach, reynolds, pitch_rate, yaw_rate, roll_rate)
        definitions.
    power_on_drag : int, float, callable, array, string, Function
        Drag coefficient input when the motor is on. Accepts the same formats
        as :class:`rocketpy.Rocket`, including 1D (Mach-only) and 7D
        (alpha, beta, mach, reynolds, pitch_rate, yaw_rate, roll_rate)
        definitions.
    weathercock_coeff : float, optional
        Proportionality coefficient for the alignment rate of the point-mass
        rocket body axis with the relative wind direction in 3-DOF
        simulations. Must be non-negative. Default is 0.0.

    Attributes
    ----------
    radius : float
        Rocket's largest radius in meters.
    mass : float
        Rocket's mass without motor in kg.
    center_of_mass_without_motor : float
        Position, in meters, of the rocket's center of mass without motor
        relative to the rocket's coordinate system.
    power_off_drag : Function
        Rocket's drag coefficient as a function of Mach number when the
        motor is off. Alias for ``power_off_drag_by_mach``.
    power_on_drag : Function
        Rocket's drag coefficient as a function of Mach number when the
        motor is on. Alias for ``power_on_drag_by_mach``.
    power_off_drag_input : int, float, callable, array, string, Function
        Original user input for the drag coefficient with motor off.
        Preserved for reconstruction and Monte Carlo workflows.
    power_on_drag_input : int, float, callable, array, string, Function
        Original user input for the drag coefficient with motor on.
        Preserved for reconstruction and Monte Carlo workflows.
    power_off_drag_7d : Function
        Drag coefficient function with seven inputs in the order:
        alpha, beta, mach, reynolds, pitch_rate, yaw_rate, roll_rate.
    power_on_drag_7d : Function
        Drag coefficient function with seven inputs in the order:
        alpha, beta, mach, reynolds, pitch_rate, yaw_rate, roll_rate.
    power_off_drag_by_mach : Function
        Convenience wrapper for power-off drag as a Mach-only function.
    power_on_drag_by_mach : Function
        Convenience wrapper for power-on drag as a Mach-only function.
    weathercock_coeff : float
        Proportionality coefficient for weathercocking alignment in 3-DOF
        simulations.
    """

    def __init__(
        self,
        radius: float,
        mass: float,
        center_of_mass_without_motor: float,
        power_off_drag,
        power_on_drag,
        weathercock_coeff: float = 0.0,
    ):
        self._center_of_mass_without_motor_pointmass = center_of_mass_without_motor
        self._center_of_dry_mass_position = center_of_mass_without_motor
        self._center_of_mass = center_of_mass_without_motor
        # Dry inertias are zero for point mass
        self.dry_I_11 = 0.0
        self.dry_I_22 = 0.0
        self.dry_I_33 = 0.0
        self.dry_I_12 = 0.0
        self.dry_I_13 = 0.0
        self.dry_I_23 = 0.0

        self.weathercock_coeff = float(weathercock_coeff)

        # Call base init with safe defaults
        super().__init__(
            radius=radius,
            mass=mass,
            inertia=(0, 0, 0),
            power_off_drag=power_off_drag,
            power_on_drag=power_on_drag,
            center_of_mass_without_motor=center_of_mass_without_motor,
        )

    def evaluate_dry_inertias(self):
        """Override to ensure inertias remain zero for point mass model.

        Returns
        -------
        tuple
            All inertia components as zeros.
        """
        self.dry_I_11 = 0.0
        self.dry_I_22 = 0.0
        self.dry_I_33 = 0.0
        self.dry_I_12 = 0.0
        self.dry_I_13 = 0.0
        self.dry_I_23 = 0.0
        return (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

    def evaluate_inertias(self):
        """Override to ensure inertias remain zero for point mass model.

        Returns
        -------
        tuple
            All inertia components as zeros.
        """
        self.I_11 = 0.0
        self.I_22 = 0.0
        self.I_33 = 0.0
        self.I_12 = 0.0
        self.I_13 = 0.0
        self.I_23 = 0.0
        return (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
