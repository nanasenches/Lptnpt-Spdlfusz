
import datetime
import threading
import json
import io
import numpy as np
from rocketpy import Environment, Flight, Rocket, SolidMotor
from rocketpy.stochastic import (
    StochasticEnvironment,
    StochasticFlight,
    StochasticNoseCone,
    StochasticRailButtons,
    StochasticRocket,
    StochasticSolidMotor,
    StochasticTail,
    StochasticTrapezoidalFins,
    StochasticParachute,
)


def modifica(
    # Ambiente
    data_hora=None,
    latitude=None,
    longitude=None,
    timezone=None,

    # Motor
    densidade=None,
    separacao_entre_graos=None,

    # Estrutura
    massa=None,
    Ixx=None,
    Izz=None,
    cm_sem_motor=None,

    # Lançamento
    tam_haste=None,
    inclinacao=None,
    direcao=None,

    # Tipo de voo
    tipo_voo=None,
):
    """Permite modificar parâmetros específicos do código RocketPy de forma curta e rápida"""

    global env, Proton, Atlas, flightStage, stochastic_env, stochastic_Motor, stochastic_Atlas, stochastic_Nosecone, stochastic_Fins, stochastic_boattail, stochastic_rail_buttons, stochastic_flight, stochastic_main_parachute, stochastic_drogue_parachute, ensemble_member   
    # Caso haja alguma mudança, o global modificará automaticamente os objetos do RocketPy, sem necessidade de return.

    ambiente_modificado = any(p is not None for p in [data_hora, latitude, longitude, timezone])
    motor_modificado = any(p is not None for p in [densidade, separacao_entre_graos])
    estrutura_modificada = any(p is not None for p in [massa, Ixx, Izz, cm_sem_motor])
    lancamento_modificado = any(p is not None for p in [tam_haste, inclinacao, direcao])
    voo_modificado = tipo_voo is not None

    algo_mudou = any([ambiente_modificado, motor_modificado, estrutura_modificada, lancamento_modificado, voo_modificado])

    if not algo_mudou:
        print("\nNenhuma modificação foi feita\n")
        return

    # -------------------------------------------------------------------------

    if ambiente_modificado:

        env = Environment(
            latitude = -15.6016,                # Launch site latitude
            longitude= -47.2407,                # Launch site longitude
            timezone = 'America/Sao_Paulo',     # Timezone
            datum="WGS84"                       # Coordinate source (global GPS standard)
        )

        DATETIME = datetime.datetime.fromisoformat("2026-10-01 10:00:00")       # Launch datetime (used to fetch weather conditions)
        env.set_date(DATETIME)


        #env.set_atmospheric_model(type="custom_atmosphere",  wind_u = 0, wind_v = 2.8, temperature = , pressure = )  # 10 km/h winds test

        result = {"success": False, "error": None}

        def download_gfs():                                                      # Function to fetch Windy - ECMWF atmospheric data
            try:
                env.set_atmospheric_model(type="Forecast", file="GFS")           # Atmospheric model
                result["success"] = True
            except Exception as e:
                result["error"] = e

        thread = threading.Thread(target=download_gfs)                          # Since GFS files needs internet access, a backup local data
        thread.start()                                                          # file is required in case the GFS download fails
        thread.join(timeout=30)  # waits up to 30 seconds 


        if thread.is_alive() or not result["success"]:
            print("GFS did not respond — using local data file as fallback")

            with open("ECMWF_04092026.json", "r") as f:                         # Open local ECMWF data file
                data = json.load(f)

            def parse_profile(s):
                return np.loadtxt(io.StringIO(s.replace("[", "").replace("]", "")))

            pressure    = parse_profile(data["atmospheric_model_pressure_profile"])
            temperature = parse_profile(data["atmospheric_model_temperature_profile"])
            wind_u      = parse_profile(data["atmospheric_model_wind_velocity_x_profile"])
            wind_v      = parse_profile(data["atmospheric_model_wind_velocity_y_profile"])

            env.set_atmospheric_model(
                type="custom_atmosphere",
                pressure=pressure.tolist(),
                temperature=temperature.tolist(),
                wind_u=wind_u.tolist(),
                wind_v=wind_v.tolist(),
            )


        env.set_topographic_profile(type="NASADEM_HGT", file="NASADEM_NC_s16w048.nc", dictionary="netCDF4", crs=None)       # Topographic model

        elevation = env.get_elevation_from_topographic_profile(env.latitude, env.longitude)

        env.set_elevation(elevation)

        stochastic_env = StochasticEnvironment(
            environment=env,
            ensemble_member=ensemble_member,
            wind_velocity_x_factor=(1.0, 0.1),      
            wind_velocity_y_factor=(1.0, 0.1),      
        )

    # -------------------------------------------------------------------------

    if motor_modificado:

        Proton = SolidMotor(
            thrust_source="EmpuxoReal_ATLAS_Final.eng",
            dry_mass = 8.53,               
            dry_inertia=(1.065, 1.065, 0.02377),
            nozzle_radius= 32.27 / 1000,
            grain_number= 6,
            grain_density= densidade if densidade is not None else 1730,
            grain_outer_radius= 45 / 1000,
            grain_initial_inner_radius= 19.05 / 1000,
            grain_initial_height= 140 / 1000,
            grain_separation= separacao_entre_graos if separacao_entre_graos is not None else 12 / 1000,
            grains_center_of_mass_position= 545.10 / 1000,
            center_of_dry_mass_position= 521.05 / 1000,
            nozzle_position= 0 /1000,
            throat_radius= 13.5 / 1000,
            coordinate_system_orientation="nozzle_to_combustion_chamber",
        )
        stochastic_Motor = StochasticSolidMotor(
            solid_motor=Proton,
            burn_start_time=(0, 0.01, "binomial"), 
            grains_center_of_mass_position= 0,
            grain_density= 0,
            grain_separation= 0 / 1000,
            grain_initial_height= 0 / 1000,
            grain_initial_inner_radius= 0 / 1000,
            grain_outer_radius= 0 / 1000,
            total_impulse= 85,
            throat_radius= 0 / 1000,  
            nozzle_radius= 0 / 1000, 
            nozzle_position= 0,
        )

    # -------------------------------------------------------------------------

    if estrutura_modificada:

        Atlas = Rocket(
            radius= 76.2/1000,
            mass= massa if massa is not None else 16234/1000,
            inertia= (Ixx if Ixx is not None else 15.9, Ixx if Ixx is not None else 15.9, Izz if Izz is not None else 0.09221),
            power_off_drag="Atlas_CD_OR_Rugosidade-20micro.csv",          
            power_on_drag="Atlas_CD_OR_Rugosidade-20micro.csv",      
            center_of_mass_without_motor= cm_sem_motor if cm_sem_motor is not None else 1317/1000,
            coordinate_system_orientation="nose_to_tail",
        )

        Nosecone = Atlas.add_nose(
            length= 850/1000, kind="Von Karman", position=0
        )

        Fins = Atlas.add_trapezoidal_fins(
            n=4,
            root_chord = 290/1000,
            tip_chord = 52/1000,
            span = 142.1/1000,
            position = 2417/1000,
            cant_angle = 0,
            sweep_length = 228/1000,
        )

        Atlas.add_motor(Proton, position= 2702/1000)

        boattail = Atlas.add_tail(
            top_radius=76.2/1000, bottom_radius=64.5/1000, length=300/1000, position=2407/1000, name="Conical Boattail",
        )

        rail_buttons = Atlas.set_rail_buttons(
            upper_button_position= 1630/1000,
            lower_button_position= 2382/1000,
            angular_position=45,
        )

        stochastic_Atlas = StochasticRocket(
            rocket=Atlas,
            radius= 0.001,
            mass=(16234/1000, 100/1000, "normal"), 
            inertia_11=(15.9, 0.001),
            inertia_22=0.001,
            inertia_33=0.0001,
            center_of_mass_without_motor=0.005,
            power_off_drag_factor=(1, 0.05),  
            power_on_drag_factor=(1, 0.05),     
        )

        stochastic_Nosecone = StochasticNoseCone(
            nosecone=Nosecone,
            length=0.001,
        )

        stochastic_Fins = StochasticTrapezoidalFins(
            trapezoidal_fins=Fins,
            root_chord=0.0005,
            tip_chord=0.0005,
            span=0.0005,
        )

        stochastic_boattail = StochasticTail(
            tail=boattail,
            top_radius=0.0005,
            bottom_radius=0.0005,
            length=0.001,
        )

        stochastic_rail_buttons = StochasticRailButtons(
            rail_buttons=rail_buttons, buttons_distance=0.0005
        )

        stochastic_Atlas.add_motor(stochastic_Motor, position=0.001)
        stochastic_Atlas.add_nose(stochastic_Nosecone, position=(0, 0.001))
        stochastic_Atlas.add_trapezoidal_fins(stochastic_Fins, position=(0.001, "normal"))
        stochastic_Atlas.add_tail(stochastic_boattail)
        stochastic_Atlas.set_rail_buttons(stochastic_rail_buttons, lower_button_position=(0.0005, "normal"))

    # -------------------------------------------------------------------------

    if lancamento_modificado or ambiente_modificado or motor_modificado or estrutura_modificada or voo_modificado:

        # Remove paraquedas existentes antes de reconfigurar
        Atlas.parachutes.clear()
        stochastic_Atlas.parachutes.clear()

        if tipo_voo is None or tipo_voo == "Nominal":
            main_parachute = Atlas.add_parachute( 
                name="Main Parachute Atlas",
                cd_s=5.7123,     
                trigger= 450,   
                sampling_rate=50,   
                lag=0.118,      
            )

            drogue_parachute = Atlas.add_parachute( 
                name="Drogue Parachute Atlas",
                cd_s=0.9379,     
                trigger= "apogee",  
                sampling_rate=50,   
                lag=4,      
            )
            stochastic_main_parachute = StochasticParachute(
            parachute=main_parachute,
            cd_s=0.2,   
            lag=0.032,  
            )

            stochastic_drogue_parachute = StochasticParachute(
                parachute=drogue_parachute,
                cd_s=0.2,   
                lag=0.032,  
            )
            stochastic_Atlas.add_parachute(stochastic_main_parachute)
            stochastic_Atlas.add_parachute(stochastic_drogue_parachute)

        elif tipo_voo == "Ballistic":
            pass  # nenhum paraquedas adicionado

        elif tipo_voo == "MainOnApogee":
            main_parachute = Atlas.add_parachute( 
                name="Main Parachute Atlas",
                cd_s=5.7123,     
                trigger= "apogee",   
                sampling_rate=50,   
                lag=4,      
            )
            stochastic_main_parachute = StochasticParachute(
                parachute=main_parachute,
                cd_s=0.2,   
                lag=0.032,  
            )
            stochastic_Atlas.add_parachute(stochastic_main_parachute)

           
        elif tipo_voo == "DrogueOnly":
            drogue_parachute = Atlas.add_parachute( 
                name="Drogue Parachute Atlas",
                cd_s=0.9379,     
                trigger= "apogee",  
                sampling_rate=50,   
                lag=4,      
            )
            stochastic_drogue_parachute = StochasticParachute(
                parachute=drogue_parachute,
                cd_s=0.2,   
                lag=0.032,  
            )
            stochastic_Atlas.add_parachute(stochastic_drogue_parachute)


        flightStage = Flight(
            rocket=Atlas,
            environment=env,
            rail_length= tam_haste if tam_haste is not None else 4,
            inclination= inclinacao if inclinacao is not None else 85,
            heading= direcao if direcao is not None else 310,
        )
        stochastic_flight = StochasticFlight(
            flight=flightStage,
            rail_length=(4, 0.01),
            inclination=(85, 1),  
            heading=(310, 2),     
        )

    # -------------------------------------------------------------------------

    print("\nModificações feitas com sucesso!\n")